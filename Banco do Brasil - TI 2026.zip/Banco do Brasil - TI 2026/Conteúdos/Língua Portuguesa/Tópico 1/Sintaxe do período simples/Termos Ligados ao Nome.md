
Todo termo preposicionado é subordinado (o que quer dizer que ele precisa obedecer por exemplo ao verbo).

Adjunto adnominal:
	Pode ou não ser preposicionado;

Complemento nominal:
	Sempre é preposicionado;

Como diferenciar o Adjunto adnominal do predicativo do sujeito? O adjunto adnominal vai estar junto ao nome (na mesma estrutura sintática (Sujeito, verbo, complemento, etc)) e o predicativo do sujeito vai estar em outra estrutura sintática.